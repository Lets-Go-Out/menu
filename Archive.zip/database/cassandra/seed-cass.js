const client = require('./connect')

// const query = 
// COPY menus.restaurant_menus FROM '/Users/jennummerdor/hrphx/sdc/menu/database/cassandra/menus/restaurant_menus/meals1.csv' WITH DELIMITER='^' AND MAXBATCHSIZE = 2 AND CHUNKSIZE = 50;
// COPY menus.restaurant_menus FROM '/Users/jennummerdor/hrphx/sdc/menu/database/cassandra/menus/restaurant_menus/meals2.csv' WITH DELIMITER='^'AND MAXBATCHSIZE = 2 AND CHUNKSIZE = 50;
// COPY menus.restaurant_menus FROM '/Users/jennummerdor/hrphx/sdc/menu/database/cassandra/menus/restaurant_menus/meals3.csv' WITH DELIMITER='^'AND MAXBATCHSIZE = 2 AND CHUNKSIZE = 50;
// COPY menus.restaurant_menus FROM '/Users/jennummerdor/hrphx/sdc/menu/database/cassandra/menus/restaurant_menus/meals4.csv' WITH DELIMITER='^'AND MAXBATCHSIZE = 2 AND CHUNKSIZE = 50;
// COPY menus.restaurant_menus FROM '/Users/jennummerdor/hrphx/sdc/menu/database/cassandra/menus/restaurant_menus/meals5.csv' WITH DELIMITER='^'AND MAXBATCHSIZE = 2 AND CHUNKSIZE = 50;

//COPY menus.restaurant_menus FROM '/Users/student/Desktop/menu/database/cassandra/records/meals1.csv' WITH DELIMITER='^' AND MAXBATCHSIZE = 2 AND CHUNKSIZE = 100;

nodemon server/server.js

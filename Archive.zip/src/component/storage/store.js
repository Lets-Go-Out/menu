import { createStore } from "redux";
import Reducers from "../reducers/reducer.jsx";

const store = createStore(Reducers);

export default store;
